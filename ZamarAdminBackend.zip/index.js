import express from "express";
import dotenv from "dotenv";
import db from "./config/db.js";
import authroutes from "./routes/auth.routes.js";
import imageRoutes from "./routes/images.routes.js";

dotenv.config();
const PORT = process.env.PORT;
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// database connection
db;

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.use("/api/auth", authroutes);

app.use("/", imageRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
